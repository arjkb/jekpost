JekPost
=========

Command-line utility to create a Jekyll post file with appropriate filename and headers.


USAGE
-----

To create a new Jekyll post:

::

  $ jekpost 'Post Title' dir

``dir`` is the directory where the new post will be saved.
This is usually the ``_posts`` directory.
